package com.bharathustle;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class BharatHustleApplicationTests {
 @Test void contextLoads() {}
}
