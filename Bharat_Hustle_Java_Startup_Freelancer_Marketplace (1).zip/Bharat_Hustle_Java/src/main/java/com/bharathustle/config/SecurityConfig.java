package com.bharathustle.config;
import com.bharathustle.service.CustomUserDetailsService;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
public class SecurityConfig {
 @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean DaoAuthenticationProvider authenticationProvider(CustomUserDetailsService service,PasswordEncoder encoder){
  DaoAuthenticationProvider p=new DaoAuthenticationProvider();p.setUserDetailsService(service);p.setPasswordEncoder(encoder);return p;
 }
 @Bean SecurityFilterChain filterChain(HttpSecurity http,DaoAuthenticationProvider provider)throws Exception{
  http.authenticationProvider(provider).authorizeHttpRequests(auth->auth
   .requestMatchers("/","/register","/login","/css/**","/js/**","/images/**","/error").permitAll()
   .requestMatchers("/admin/**").hasRole("ADMIN")
   .requestMatchers("/projects/new","/projects/*/applications/**").hasAnyRole("STARTUP","CLIENT")
   .requestMatchers("/apply/**","/my-applications").hasRole("FREELANCER")
   .anyRequest().authenticated())
   .formLogin(form->form.loginPage("/login").defaultSuccessUrl("/dashboard",true).permitAll())
   .logout(logout->logout.logoutSuccessUrl("/").permitAll());
  return http.build();
 }
}
