package com.bharathustle.config;
import com.bharathustle.entity.*;
import com.bharathustle.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.List;
@Configuration
public class DemoData {
 @Bean CommandLineRunner seed(UserRepository users,ProjectRepository projects,PasswordEncoder encoder){
  return args -> {
   if(users.count()>0)return;
   User admin=user("Platform Admin","admin@bharathustle.demo","Admin@12345",Role.ADMIN,encoder);
   User startup=user("NovaTech Labs","startup@bharathustle.demo","Startup@123",Role.STARTUP,encoder);
   User freelancer=user("Aarav Sharma","freelancer@bharathustle.demo","Freelancer@123",Role.FREELANCER,encoder);
   User client=user("Demo Client","client@bharathustle.demo","Client@12345",Role.CLIENT,encoder);
   users.saveAll(List.of(admin,startup,freelancer,client));
   Project p=new Project();p.setOwner(startup);p.setTitle("Build a campus opportunity portal");p.setCategory("Web Development");
   p.setDescription("Create a responsive portal where students can discover internships, events, projects and collaboration opportunities.");
   p.setSkills("Java, Spring Boot, MySQL, HTML, CSS");p.setBudget(25000);projects.save(p);
   Project p2=new Project();p2.setOwner(startup);p2.setTitle("IoT sensor monitoring dashboard");p2.setCategory("IoT");
   p2.setDescription("Build a dashboard to monitor temperature and humidity data from ESP32 devices.");p2.setSkills("Java, REST API, IoT, Charts");p2.setBudget(18000);projects.save(p2);
  };
 }
 private User user(String name,String email,String pass,Role role,PasswordEncoder e){User u=new User();u.setName(name);u.setEmail(email);u.setPassword(e.encode(pass));u.setRole(role);return u;}
}
