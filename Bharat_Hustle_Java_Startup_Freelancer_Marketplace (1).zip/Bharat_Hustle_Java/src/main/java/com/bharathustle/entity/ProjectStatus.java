package com.bharathustle.entity;
public enum ProjectStatus { OPEN, IN_PROGRESS, COMPLETED, CLOSED }
