package com.bharathustle.entity;
public enum Role { STARTUP, FREELANCER, CLIENT, ADMIN }
