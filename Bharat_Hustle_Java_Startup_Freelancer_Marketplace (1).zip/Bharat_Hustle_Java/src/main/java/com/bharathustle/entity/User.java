package com.bharathustle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name="users", uniqueConstraints=@UniqueConstraint(columnNames="email"))
public class User {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank private String name;
 @Email @NotBlank private String email;
 @NotBlank private String password;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private Role role;
 private String headline;
 @Column(length=1500) private String bio;
 private String skills;
 private Integer hourlyRate=0;
 private LocalDateTime createdAt=LocalDateTime.now();
 public User() {}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getName(){return name;} public void setName(String name){this.name=name;}
 public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
 public String getPassword(){return password;} public void setPassword(String password){this.password=password;}
 public Role getRole(){return role;} public void setRole(Role role){this.role=role;}
 public String getHeadline(){return headline;} public void setHeadline(String headline){this.headline=headline;}
 public String getBio(){return bio;} public void setBio(String bio){this.bio=bio;}
 public String getSkills(){return skills;} public void setSkills(String skills){this.skills=skills;}
 public Integer getHourlyRate(){return hourlyRate;} public void setHourlyRate(Integer hourlyRate){this.hourlyRate=hourlyRate;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
