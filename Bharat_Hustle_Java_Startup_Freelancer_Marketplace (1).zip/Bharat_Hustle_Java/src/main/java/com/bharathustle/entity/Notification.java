package com.bharathustle.entity;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity
public class Notification {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private User user;
 @Column(nullable=false,length=500) private String message;
 private boolean readFlag=false;
 private LocalDateTime createdAt=LocalDateTime.now();
 public Notification(){}
 public Notification(User user,String message){this.user=user;this.message=message;}
 public Long getId(){return id;} public User getUser(){return user;} public String getMessage(){return message;}
 public boolean isReadFlag(){return readFlag;} public void setReadFlag(boolean v){readFlag=v;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
