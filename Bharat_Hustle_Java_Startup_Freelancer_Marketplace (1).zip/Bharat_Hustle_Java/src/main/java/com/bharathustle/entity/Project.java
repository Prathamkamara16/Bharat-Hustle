package com.bharathustle.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Project {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private User owner;
 @NotBlank private String title;
 private String category;
 @Column(length=4000) @NotBlank private String description;
 private String skills;
 private Integer budget=0;
 private LocalDate deadline;
 @Enumerated(EnumType.STRING) private ProjectStatus status=ProjectStatus.OPEN;
 private LocalDateTime createdAt=LocalDateTime.now();
 public Project(){}
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public User getOwner(){return owner;} public void setOwner(User owner){this.owner=owner;}
 public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
 public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
 public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
 public String getSkills(){return skills;} public void setSkills(String skills){this.skills=skills;}
 public Integer getBudget(){return budget;} public void setBudget(Integer budget){this.budget=budget;}
 public LocalDate getDeadline(){return deadline;} public void setDeadline(LocalDate deadline){this.deadline=deadline;}
 public ProjectStatus getStatus(){return status;} public void setStatus(ProjectStatus status){this.status=status;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
