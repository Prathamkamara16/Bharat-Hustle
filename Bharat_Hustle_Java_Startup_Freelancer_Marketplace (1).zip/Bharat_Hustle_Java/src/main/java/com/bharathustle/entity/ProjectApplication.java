package com.bharathustle.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="project_applications", uniqueConstraints=@UniqueConstraint(columnNames={"project_id","freelancer_id"}))
public class ProjectApplication {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private Project project;
 @ManyToOne(optional=false) @JoinColumn(name="freelancer_id") private User freelancer;
 @Column(length=2500, nullable=false) private String proposal;
 @Enumerated(EnumType.STRING) private ApplicationStatus status=ApplicationStatus.PENDING;
 private LocalDateTime createdAt=LocalDateTime.now();
 public ProjectApplication(){}
 public Long getId(){return id;} public Project getProject(){return project;} public void setProject(Project v){project=v;}
 public User getFreelancer(){return freelancer;} public void setFreelancer(User v){freelancer=v;}
 public String getProposal(){return proposal;} public void setProposal(String v){proposal=v;}
 public ApplicationStatus getStatus(){return status;} public void setStatus(ApplicationStatus v){status=v;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
