package com.bharathustle.entity;
import jakarta.persistence.*; import java.time.LocalDateTime;
@Entity
public class Message {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) @JoinColumn(name="sender_id") private User sender;
 @ManyToOne(optional=false) @JoinColumn(name="recipient_id") private User recipient;
 @Column(nullable=false,length=3000) private String body;
 private LocalDateTime createdAt=LocalDateTime.now();
 public Message(){}
 public Message(User s,User r,String b){sender=s;recipient=r;body=b;}
 public Long getId(){return id;} public User getSender(){return sender;} public User getRecipient(){return recipient;}
 public String getBody(){return body;} public LocalDateTime getCreatedAt(){return createdAt;}
}
