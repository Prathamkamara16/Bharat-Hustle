package com.bharathustle.entity;
public enum ApplicationStatus { PENDING, SHORTLISTED, ACCEPTED, REJECTED }
