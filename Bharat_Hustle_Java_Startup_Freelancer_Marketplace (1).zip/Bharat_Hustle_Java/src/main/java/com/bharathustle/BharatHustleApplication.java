package com.bharathustle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BharatHustleApplication {
    public static void main(String[] args) {
        SpringApplication.run(BharatHustleApplication.class, args);
    }
}
