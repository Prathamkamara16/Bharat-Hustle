package com.bharathustle.controller;

import com.bharathustle.entity.*;
import com.bharathustle.repository.*;
import com.bharathustle.service.MarketplaceService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Optional;

@Controller
public class WebController {
 private final UserRepository users; private final ProjectRepository projects; private final ProjectApplicationRepository applications;
 private final MarketplaceService service; private final PasswordEncoder encoder;
 public WebController(UserRepository u,ProjectRepository p,ProjectApplicationRepository a,MarketplaceService s,PasswordEncoder e){users=u;projects=p;applications=a;service=s;encoder=e;}
 private User me(Authentication auth){return users.findByEmail(auth.getName()).orElseThrow();}
 @GetMapping("/") public String home(Model m){m.addAttribute("projects",service.openProjects(null).stream().limit(6).toList());m.addAttribute("freelancers",service.freelancers().stream().limit(4).toList());return "index";}
 @GetMapping("/login") public String login(){return "login";}
 @GetMapping("/register") public String register(Model m){m.addAttribute("user",new User());return "register";}
 @PostMapping("/register") public String registerPost(@Valid @ModelAttribute User user,BindingResult result,@RequestParam String role,RedirectAttributes ra){
  if(users.findByEmail(user.getEmail()).isPresent()){result.rejectValue("email","duplicate","Email already registered");}
  if(!role.matches("STARTUP|FREELANCER|CLIENT")){result.reject("role","Invalid account type");}
  if(result.hasErrors()) return "register";
  user.setRole(Role.valueOf(role));user.setPassword(encoder.encode(user.getPassword()));users.save(user);ra.addFlashAttribute("success","Account created. Please log in.");return "redirect:/login";
 }
 @GetMapping("/dashboard") public String dashboard(Authentication auth,Model m){
  User u=me(auth);m.addAttribute("user",u);
  if(u.getRole()==Role.ADMIN)return "redirect:/admin";
  if(u.getRole()==Role.FREELANCER)m.addAttribute("applications",service.myApplications(u.getId()));
  else {m.addAttribute("projects",service.ownedProjects(u.getId()));m.addAttribute("applications",service.incomingApplications(u.getId()));}
  return "dashboard";
 }
 @GetMapping("/projects") public String projects(@RequestParam(required=false) String q,Model m){m.addAttribute("projects",service.openProjects(q));m.addAttribute("q",q);return "projects";}
 @GetMapping("/projects/{id}") public String project(@PathVariable Long id,Model m){m.addAttribute("project",service.project(id));return "project-detail";}
 @GetMapping("/projects/new") public String newProject(Model m){m.addAttribute("project",new Project());return "project-form";}
 @PostMapping("/projects/new") public String createProject(@ModelAttribute Project p,Authentication auth,RedirectAttributes ra){
  Project saved=service.createProject(p,me(auth));ra.addFlashAttribute("success","Project published successfully.");return "redirect:/projects/"+saved.getId();
 }
 @PostMapping("/apply/{id}") public String apply(@PathVariable Long id,@RequestParam String proposal,Authentication auth,RedirectAttributes ra){
  try{service.apply(id,me(auth),proposal);ra.addFlashAttribute("success","Application submitted.");}
  catch(RuntimeException ex){ra.addFlashAttribute("error",ex.getMessage());}
  return "redirect:/projects/"+id;
 }
 @PostMapping("/applications/{id}/{status}") public String applicationAction(@PathVariable Long id,@PathVariable ApplicationStatus status,Authentication auth,RedirectAttributes ra){
  try{service.updateApplication(id,status,me(auth));ra.addFlashAttribute("success","Application status updated.");}
  catch(RuntimeException ex){ra.addFlashAttribute("error",ex.getMessage());}
  return "redirect:/dashboard";
 }
 @GetMapping("/my-applications") public String myApplications(Authentication auth,Model m){m.addAttribute("applications",service.myApplications(me(auth).getId()));return "my-applications";}
 @GetMapping("/freelancers") public String freelancers(Model m){m.addAttribute("freelancers",service.freelancers());return "freelancers";}
 @GetMapping("/notifications") public String notifications(Authentication auth,Model m){m.addAttribute("notifications",service.notifications(me(auth).getId()));return "notifications";}
 @GetMapping("/admin") public String admin(Model m){m.addAttribute("users",service.allUsers());m.addAttribute("userCount",service.countUsers());m.addAttribute("projectCount",service.countProjects());m.addAttribute("applicationCount",service.countApplications());return "admin";}
 @GetMapping("/messages") public String messages(Authentication auth,Model m,@RequestParam(required=false) Long with){
  User u=me(auth);m.addAttribute("people",users.findAll().stream().filter(x->!x.getId().equals(u.getId())).toList());m.addAttribute("with",with);
  if(with!=null)m.addAttribute("conversation",service.conversation(u.getId(),with));return "messages";
 }
 @PostMapping("/messages") public String sendMessage(Authentication auth,@RequestParam Long recipientId,@RequestParam String body,RedirectAttributes ra){
  User recipient=users.findById(recipientId).orElseThrow();service.sendMessage(me(auth),recipient,body);ra.addFlashAttribute("success","Message sent.");return "redirect:/messages?with="+recipientId;
 }
}
