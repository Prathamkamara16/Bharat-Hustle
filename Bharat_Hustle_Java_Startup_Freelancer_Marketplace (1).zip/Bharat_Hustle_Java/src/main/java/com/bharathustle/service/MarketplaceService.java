package com.bharathustle.service;

import com.bharathustle.entity.*;
import com.bharathustle.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class MarketplaceService {
 private final UserRepository users; private final ProjectRepository projects;
 private final ProjectApplicationRepository applications; private final NotificationRepository notifications;
 private final MessageRepository messages;
 public MarketplaceService(UserRepository u,ProjectRepository p,ProjectApplicationRepository a,NotificationRepository n,MessageRepository m){
  users=u;projects=p;applications=a;notifications=n;messages=m;
 }
 public List<Project> openProjects(String q){return q==null||q.isBlank()?projects.findByStatusOrderByCreatedAtDesc(ProjectStatus.OPEN):projects.findByStatusAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(ProjectStatus.OPEN,q);}
 public List<Project> ownedProjects(Long userId){return projects.findByOwnerIdOrderByCreatedAtDesc(userId);}
 public Project project(Long id){return projects.findById(id).orElseThrow(()->new IllegalArgumentException("Project not found"));}
 @Transactional public Project createProject(Project p,User owner){p.setOwner(owner);p.setStatus(ProjectStatus.OPEN);return projects.save(p);}
 @Transactional public ProjectApplication apply(Long projectId,User freelancer,String proposal){
  Project p=project(projectId);
  if(p.getStatus()!=ProjectStatus.OPEN) throw new IllegalStateException("Project is not open");
  if(applications.existsByProjectIdAndFreelancerId(projectId,freelancer.getId())) throw new IllegalStateException("You have already applied");
  ProjectApplication a=new ProjectApplication();a.setProject(p);a.setFreelancer(freelancer);a.setProposal(proposal);
  notifications.save(new Notification(p.getOwner(),"New application from "+freelancer.getName()+" for "+p.getTitle()));
  return applications.save(a);
 }
 @Transactional public void updateApplication(Long appId,ApplicationStatus status,User owner){
  ProjectApplication a=applications.findById(appId).orElseThrow(()->new IllegalArgumentException("Application not found"));
  if(!a.getProject().getOwner().getId().equals(owner.getId())) throw new SecurityException("Not your project");
  a.setStatus(status);
  if(status==ApplicationStatus.ACCEPTED) a.getProject().setStatus(ProjectStatus.IN_PROGRESS);
  notifications.save(new Notification(a.getFreelancer(),"Your application for "+a.getProject().getTitle()+" is "+status.name().toLowerCase()));
 }
 public List<ProjectApplication> myApplications(Long id){return applications.findByFreelancerIdOrderByCreatedAtDesc(id);}
 public List<ProjectApplication> incomingApplications(Long id){return applications.findByProjectOwnerIdOrderByCreatedAtDesc(id);}
 public List<Notification> notifications(Long id){return notifications.findByUserIdOrderByCreatedAtDesc(id);}
 public List<User> freelancers(){return users.findByRole(Role.FREELANCER);}
 public List<User> allUsers(){return users.findAll();}
 public long countUsers(){return users.count();} public long countProjects(){return projects.count();}
 public long countApplications(){return applications.count();}
 @Transactional public void sendMessage(User sender,User recipient,String body){messages.save(new Message(sender,recipient,body));notifications.save(new Notification(recipient,"New message from "+sender.getName()));}
 public List<Message> conversation(Long a,Long b){return messages.findBySenderIdAndRecipientIdOrSenderIdAndRecipientIdOrderByCreatedAtAsc(a,b,b,a);}
}
