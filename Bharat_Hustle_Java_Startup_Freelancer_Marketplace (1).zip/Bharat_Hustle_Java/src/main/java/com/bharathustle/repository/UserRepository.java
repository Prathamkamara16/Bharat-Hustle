package com.bharathustle.repository;
import com.bharathustle.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface UserRepository extends JpaRepository<User,Long> {
 Optional<User> findByEmail(String email); List<User> findByRole(Role role);
}
