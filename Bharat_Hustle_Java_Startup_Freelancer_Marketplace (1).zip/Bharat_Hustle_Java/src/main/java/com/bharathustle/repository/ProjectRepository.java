package com.bharathustle.repository;
import com.bharathustle.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface ProjectRepository extends JpaRepository<Project,Long> {
 List<Project> findByStatusOrderByCreatedAtDesc(ProjectStatus status);
 List<Project> findByOwnerIdOrderByCreatedAtDesc(Long ownerId);
 List<Project> findByStatusAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(ProjectStatus status,String title);
}
