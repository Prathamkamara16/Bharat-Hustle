package com.bharathustle.repository;
import com.bharathustle.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface MessageRepository extends JpaRepository<Message,Long> {
 List<Message> findBySenderIdAndRecipientIdOrSenderIdAndRecipientIdOrderByCreatedAtAsc(Long s1,Long r1,Long s2,Long r2);
}
