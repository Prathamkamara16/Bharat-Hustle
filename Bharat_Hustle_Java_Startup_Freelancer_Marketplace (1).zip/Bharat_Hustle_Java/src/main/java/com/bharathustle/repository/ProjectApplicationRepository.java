package com.bharathustle.repository;
import com.bharathustle.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface ProjectApplicationRepository extends JpaRepository<ProjectApplication,Long> {
 boolean existsByProjectIdAndFreelancerId(Long projectId,Long freelancerId);
 List<ProjectApplication> findByFreelancerIdOrderByCreatedAtDesc(Long id);
 List<ProjectApplication> findByProjectOwnerIdOrderByCreatedAtDesc(Long ownerId);
}
