package com.bharathustle.repository;
import com.bharathustle.entity.*; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface NotificationRepository extends JpaRepository<Notification,Long> {
 List<Notification> findByUserIdOrderByCreatedAtDesc(Long userId);
 long countByUserIdAndReadFlagFalse(Long userId);
}
