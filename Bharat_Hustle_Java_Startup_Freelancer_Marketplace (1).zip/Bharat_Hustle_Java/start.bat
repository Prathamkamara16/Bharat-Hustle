@echo off
cd /d "%~dp0"
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven is not installed or not available on PATH.
  echo Install Apache Maven, then run this file again.
  pause
  exit /b 1
)
call mvn spring-boot:run
pause
